# Generate Least squares regressions of distance from geographic origins 
# against variance in shape
# Ensure you import YMB_Data
# Set values
  # These commands set the variables within YMB_Data to easier to read objects.
Variance<-YMB_Data$Weighted.mean.within.group.variance
Distance_Hokkaido<-YMB_Data$Distance.from.Hokkaido
Distance_Sakhalin<-YMB_Data$Distance.from.Sakhalin
Distance_Amur<-YMB_Data$Distance.from.Amur
Distance_Yakutia<-YMB_Data$Distance.from.Yakutia
Distance_NES<-YMB_Data$Distance.from.NES
Distance_Swan_Point<-YMB_Data$Distance.from.Swan.Point
# Run regressions
  # These commands generate linear models for each geographic origin against 
  # the variance value because we want to understand whether there is an 
  # inverse relationship between the two variables.
  # Distance values plotted on x-axis, Variance on y-axis.
HK_Regress<-lm(Variance~Distance_Hokkaido)
SK_Regress<-lm(Variance~Distance_Sakhalin)
Amur_Regress<-lm(Variance~Distance_Amur)
YK_Regress<-lm(Variance~Distance_Yakutia)
NES_Regress<-lm(Variance~Distance_NES)
SP_Regress<-lm(Variance~Distance_Swan_Point)
# Acquire Pearson's Correlation Coefficient - "r"
  # Retrieves Pearson's r using the same data utilized in the various 
  # regression models to understand if the models show a negative correlation 
  # and the strength of that correlation.
cor(Distance_Hokkaido,Variance)
cor(Distance_Sakhalin,Variance)
cor(Distance_Amur,Variance)
cor(Distance_Yakutia,Variance)
cor(Distance_NES,Variance)
cor(Distance_Swan_Point,Variance)
# Plots Hokkaido regression.
  # Simple plot of Hokkaido centered origin regression model
  # Plots Geographic distance from Hokkaido on x-axis against Variance on 
  # the y-axis for visual inspection.
  # Draws best fit line that represents the slope and intercept of the 
  # regression model to understand Pearson's r. 
    # Value "Distance_Hokkaido" can be replaced with other values representing 
    # the geographic distances from different origins.
library(ggplot2)
ggplot() + geom_point(aes(Distance_Hokkaido,Variance)) + 
  geom_smooth(aes(Distance_Hokkaido,Variance), method="lm", se=F) +
  theme_bw() +
  xlab("Distance from Hokkaido (km)") + 
  ylab("Variance")

# Generate the effect of core reduction on shape variables.
# Ensure you import RW_W_Data.
# Set objects
  # Sets variables to named objects for easier visual inspection.
Width<-RW_W$Width
Width_RelW1<-RW_W$RW1
Width_RelW2<-RW_W$RW2
# Generates linear regressions for Width against Relative warps 1 and 2
  # Width plotted on x-axis, Variance on y-axis.
  # Generates values (r^2, p) to understand the strength and significance of 
  # the effect of width on the first two principal shape values.
RW1_Width_regress<-lm(Width_RelW1~Width)
RW2_Width_regress<-lm(Width_RelW2~Width)

# Generates plots visualizing the regressions
ggplot() + geom_point(aes(Width,Width_RelW1)) + 
  geom_smooth(aes(Width,Width_RelW1), method = "lm", se=F) + 
  theme_bw() + 
  xlab("Platform Width (mm)") +
  ylab("RW1")

ggplot() + geom_point(aes(Width,Width_RelW2)) + 
  geom_smooth(aes(Width,Width_RelW2), method = "lm", se=F) + 
  theme_bw() + 
  xlab("Platform Width (mm)") +
  ylab("RW2")

# Import RW_L_Data
# Set objects
  # Sets variables to named objects for easier visual inspection
Length<-RW_L$Length
Length_RelW1<-RW_L$RW1
Length_RelW2<-RW_L$RW2
# Generates linear regressions for Length against Relative warps 1 and 2
# Length plotted on x-axis, Variance on y-axis.
# Generates values (r^2, p) to understand the strength and significance of 
# the effect of length on the first two principal shape values.
RW1_Length_regress<-lm(Length_RelW1~Length)
RW2_Length_regress<-lm(Length_RelW2~Length)

# Generates plots visualizing the regressions
ggplot() + geom_point(aes(Length,Length_RelW1)) + 
  geom_smooth(aes(Length,Length_RelW1), method = "lm", se=F) + 
  theme_bw() + 
  xlab("Platform Length (mm)") +
  ylab("RW1")

ggplot() + geom_point(aes(Length,Length_RelW2)) + 
  geom_smooth(aes(Length,Length_RelW1), method = "lm", se=F) + 
  theme_bw() + 
  xlab("Platform Length (mm)") +
  ylab("RW2")